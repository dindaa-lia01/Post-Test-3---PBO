package models;
import java.time.LocalDate;

public class ObatResep extends Obat {
    private String anjuranDokter;
    private String nomorResep;

    public ObatResep(String namaObat, String kategori, LocalDate expiredDate, int stok, double harga,
                    String anjuranDokter, String nomorResep) {
        super(namaObat, kategori, expiredDate, stok, harga);
        this.anjuranDokter = anjuranDokter;
        this.nomorResep = nomorResep;
    }

    public String getAnjuranDokter() { return anjuranDokter; }
    public void setAnjuranDokter(String anjuranDokter) { this.anjuranDokter = anjuranDokter; }

    public String getNomorResep() { return nomorResep; }
    public void setNomorResep(String nomorResep) { this.nomorResep = nomorResep; }

    @Override
    public void tampilkanObat() {
        System.out.println("[Obat Resep]");
        super.tampilkanObat();
        System.out.println("Nomor Resep : " + nomorResep);
        System.out.println("Anjuran     : " + anjuranDokter);
    }
}
